def f_2(n):
    for i in range(n, n**5):
        j = 0
        while j < n:
            print(i, j)
	    j += 1
