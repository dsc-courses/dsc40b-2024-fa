def f_4(arr):
    """arr is an array of size n"""
    t = 0
    for i in range(n):
        t += sum(arr)

    for j in range(n):
        print(j//t)
